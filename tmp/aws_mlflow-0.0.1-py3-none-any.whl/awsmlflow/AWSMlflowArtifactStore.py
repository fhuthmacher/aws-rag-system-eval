# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.


from awsmlflow import AWSMlflowException
from mlflow.store.artifact.http_artifact_repo import HttpArtifactRepository
from mlflow.tracking._tracking_service.utils import get_tracking_uri
import logging, os
from awsmlflow.AWSMLflowHelpers import validate_and_parse_arn

def get_tracking_server_url(tracking_server_arn: str) -> str:
    """Returns the url for the AWSMLflow Dataplane frontend
    
    Args:
       tracking_server_arn (str): Tracking Server Arn
    Returns:
        str: Tracking Server URL. 
    """
    custom_endpoint = os.environ.get("AWS_MLFLOW_CUSTOM_ENDPOINT", "")
    if custom_endpoint:
        logging.info(f"Using custom endpoint {custom_endpoint}")
        return custom_endpoint
    arn = validate_and_parse_arn(tracking_server_arn)
    dns_suffix = get_dns_suffix(arn.partition)
    reverse_proxy_endpoint = f"https://aloyreverseproxy.prod.{arn.region}.ml-platform.{dns_suffix}"
    return reverse_proxy_endpoint


def get_dns_suffix(partition: str) -> str:
    """Returns a DNS suffix for a partition
    
    Args:
        partition (str): Partition that the tracking server resides in.
    Returns:
        str: DNS suffix of the partition
    """
    if partition == "aws":
        return "aws.a2z.com"
    else:
        raise AWSMlflowException(f"Partition {partition} Not supported.")

class AWSMlflowArtifactStore(HttpArtifactRepository):
    """Scheme wrapper around HttpArtifactRepository for mlflow-artifacts server functionality"""

    is_plugin = True
    
    def __init__(self, artifact_uri):
        aws_mlflow_endpoint = get_tracking_server_url(get_tracking_uri())
        artifact_path = artifact_uri.replace("mlflow-artifacts:","")
        url = f"{aws_mlflow_endpoint}/api/2.0/mlflow-artifacts/artifacts{artifact_path}"
        os.environ["MLFLOW_TRACKING_AUTH"] = "arn"
        super().__init__(url)

    

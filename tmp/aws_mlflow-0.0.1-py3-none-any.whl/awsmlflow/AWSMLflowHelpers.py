# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.

from awsmlflow import AWSMlflowException


class Arn:
    
    """ Constructor for Arn Object
        Args:
            tracking_server_arn (str): Tracking Server Arn
    """ 
    def __init__(self, arn: str):
        splitted_arn = arn.split(":")
        self.partition = splitted_arn[1]
        self.service = splitted_arn[2]
        self.region = splitted_arn[3]
        self.account = splitted_arn[4]
        self.resource_type = splitted_arn[5].split("/")[0]
        self.resource_id = splitted_arn[5].split("/")[1]
        

def validate_and_parse_arn(tracking_server_arn: str) -> Arn:
    """Validates and returns an arn from a string.
    
    Args:
        tracking_server_arn (str): Tracking Server Arn
    Returns:
        Arn: Arn Object
    """
    arn = Arn(tracking_server_arn)
    if (
        arn.service != "sagemaker"
        or not arn.resource_type
        or not arn.resource_id
    ):
        raise AWSMlflowException(f"{tracking_server_arn} is not a valid arn")
    return arn

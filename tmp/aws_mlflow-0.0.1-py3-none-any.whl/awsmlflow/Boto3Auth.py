import boto3
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
from botocore.compat import parse_qsl, urlsplit
from requests.auth import AuthBase
import hashlib
from io import BufferedIOBase


class Sigv4Auth(AuthBase):
    """

    """

    def __init__(self, region=""):
        self.boto3_session = boto3.Session()
        region_name = region if region else self.boto3_session.region_name
        self.sigv4 = SigV4Auth(
            credentials=self.boto3_session.get_credentials(),
            service_name="aloy",
            region_name=region_name,
        )

    def __call__(self, request):
        # Parse request URL
        url = urlsplit(request.url)

        # Prepare AWS request
        awsrequest = AWSRequest(
            method=request.method,
            url=f"{url.scheme}://{url.netloc}{url.path}",
            data=request.body,
            params=dict(parse_qsl(url.query)),
        )
        
        payload_hash = ""
        if awsrequest.body:
            if isinstance(awsrequest.body, bytes):
                payload_hash = hashlib.sha256(awsrequest.body).hexdigest()
            else:
                if isinstance(awsrequest.body, BufferedIOBase):
                    awsrequest.body.seek(0)
                    payload_hash = hashlib.sha256(awsrequest.body.read()).hexdigest()
                    awsrequest.body.seek(0)
                else:
                    payload_hash = hashlib.sha256(awsrequest.body.encode('utf-8')).hexdigest()
        awsrequest.headers["x-amz-content-sha256"] = payload_hash
        awsrequest.headers["X-Amz-Content-SHA256"] = payload_hash
        

        # Sign request
        self.sigv4.add_auth(awsrequest)

        # Re-add original headers
        for key, val in request.headers.items():
            if key not in awsrequest.headers:
                awsrequest.headers[key] = val

        # Return prepared request
        return awsrequest.prepare()
# RagasBedrock

## What is this package?
This is a modified 3P package to evaluate RAG pipeline called [RAGAS](https://github.com/explodinggradients/ragas). I pulled Ragas version `v0.0.17`. Below is the dscription from original `README.md` in Ragas on github. 

`Ragas is a framework that helps you evaluate your Retrieval Augmented Generation (RAG) pipelines. RAG denotes a class of LLM applications that use external data to augment the LLM’s context. There are existing tools and frameworks that help you build these pipelines but evaluating it and quantifying your pipeline performance can be hard. This is where Ragas (RAG Assessment) comes in.`

Contact [me](https://phonetool.amazon.com/users/tianyd) (tianyd@) if you have any problems to run this package. 
## Quickstart

You can run the [jupyter notebook](https://tiny.amazon.com/gi26xbf4) in the package. Please make sure the environment you are running this notebook has the access to bedrock. For example, here is the info from the AWS account I used:

```python
INFO:botocore.credentials:Found credentials from IAM Role: BaseNotebookInstanceEc2InstanceRole
```
## Knowledge Share and Next Steps
I have drafted this [RagasBedrock knowledge sharing quip document](https://quip-amazon.com/MGTsAo2XRhu4/RagasBedrock-knowledge-share) to share my knowledge of using Ragas.


## Support Community
There is an internal slack channel: [llm-evaluation](https://amzn-aws.slack.com/archives/C05TU0C0J5V). I will mainly post messages there.
## [Notification] Open Analytics of Ragas team

Ragas team has created a function to track user as following:

```
We track very basic usage metrics to guide us to figure out what our users want, what is working, and what's not. As a young startup, we have to be brutally honest about this which is why we are tracking these metrics. But as an Open Startup, we open-source all the data we collect. You can read more about this [here](https://github.com/explodinggradients/ragas/issues/49). **Ragas does not track any information that can be used to identify you or your company**. You can take a look at exactly what we track in the [code](./src/ragas/_analytics.py)
```

I have turned it off if you check the `./src/ragas/_analytics.py`.

## Documentation

Generated documentation for the latest released version can be accessed here:
https://devcentral.amazon.com/ac/brazil/package-master/package/go/documentation?name=RagasBedrock&interface=1.0&versionSet=live

## Development

See instructions in DEVELOPMENT.md

import pytest


@pytest.mark.xfail
def test_that_you_wrote_tests():
    from textwrap import dedent

    pass


def test_ragas_bedrock_importable():
    pass
